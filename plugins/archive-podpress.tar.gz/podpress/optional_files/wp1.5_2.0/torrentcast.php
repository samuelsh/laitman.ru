<?php
	define('PODPRESS_TORRENTCAST', true);
	require('wp-rss2.php');
