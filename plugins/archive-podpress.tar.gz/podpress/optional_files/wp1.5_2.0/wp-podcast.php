<?php
	define('PODPRESS_PODCASTSONLY', true);
	require('wp-rss2.php');
