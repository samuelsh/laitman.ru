<?php
	define('PREMIUMCAST', true);
	define('PODPRESS_PREMIUM_METHOD', 'Digest');
	require('wp-rss2.php');
