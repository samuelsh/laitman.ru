=== WP-Print ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: print, printer, wp-print
Requires at least: 2.8
Stable tag: 2.50

Displays a printable version of your WordPress blog's post/page.

== Description ==

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-Print Readme](http://lesterchan.net/wordpress/readme/wp-print.html "WP-Print Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-Print Readme](http://lesterchan.net/wordpress/readme/wp-print.html "WP-Print Readme") (Installation Tab)

== Screenshots ==

[WP-Print Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-print/ "WP-Print Screenshots")

== Frequently Asked Questions ==

[WP-Print Support Forums](http://forums.lesterchan.net/index.php?board=18.0 "WP-Print Support Forums")